python3 src/test_planiffiers.py \
    --planner 'planificadores/metricff' \
    --domain 'pddl/dominio-drones-parte-2.pddl' \
    --start 2 \
    --max-size 100 \
    --timeout 60